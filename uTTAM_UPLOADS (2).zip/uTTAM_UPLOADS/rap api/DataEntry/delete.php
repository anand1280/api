<?php
session_start();
if(isset($_SESSION['entry']))
{
	
		if($_SERVER['REQUEST_METHOD'] == 'GET'){

			include_once("../Database/Database_Connection.php");

			$id=$_GET['id'];
			
			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);
			
			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			} 

			// sql to delete a record
			$sql = "DELETE FROM infotable WHERE id='$id'";

			if ($conn->query($sql) === TRUE) {
			    echo "Record deleted successfully";
			} else {
			    echo "Error deleting record: " . $conn->error;
			}

			$conn->close();
			header('Location:enterdatasource.php');
		}


}else{
	header('Location:../access.php');
}

?>