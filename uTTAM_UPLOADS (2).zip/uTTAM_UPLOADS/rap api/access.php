<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
	if(isset($_POST['submit']))
	{
		$data=$_POST['access'];
		if($data=="A1B2C3D4"){
			
			session_start();
			$_SESSION['entry']="Fire";
			header('Location:DataEntry/enterdatasource.php');
		}
		else{
			echo "<h1>તમે કોણ?</h1>";
		}
	}
	?>
	<form action="access.php" method="POST">
		<input type="password" name="access">
		<input type="submit" name="submit">
	</form>	

</body>
</html>